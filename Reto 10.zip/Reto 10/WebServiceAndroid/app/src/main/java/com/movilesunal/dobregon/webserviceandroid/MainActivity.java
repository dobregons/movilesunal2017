package com.movilesunal.dobregon.webserviceandroid;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText txtAddress;
    private EditText txtName;
    private EditText txtNumber;
    private EditText txtPhone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void callServiceApi(View v)
    {
        //Toast.makeText(this, "Clicked on Button", Toast.LENGTH_LONG).show();
        //Get values from view
        txtAddress = (EditText) findViewById(R.id.address);
        txtName = (EditText) findViewById(R.id.name);
        txtNumber = (EditText) findViewById(R.id.number);
        txtPhone = (EditText) findViewById(R.id.phone);

        //Call Api datos.gov.co

        //Call activity to show the results
        Intent intent = new Intent(v.getContext(), ResultActivity.class);
        //Pass Variables to result activity
        intent.putExtra("ADDRESS", txtAddress.getText());
        intent.putExtra("NAME", txtName.getText());
        intent.putExtra("NUMBER", txtNumber.getText());
        intent.putExtra("PHONE", txtPhone.getText());

        startActivity(intent);

    }
}
