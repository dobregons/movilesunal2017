package com.movilesunal.dobregon.webserviceandroid;

import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceActivity;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.TextView;

import com.loopj.android.http.HttpGet;
import com.loopj.android.http.JsonHttpResponseHandler;
import com.loopj.android.http.RequestParams;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import cz.msebera.android.httpclient.HttpResponse;
import cz.msebera.android.httpclient.client.HttpClient;
import cz.msebera.android.httpclient.impl.client.DefaultHttpClient;
import cz.msebera.android.httpclient.impl.client.HttpClientBuilder;
import cz.msebera.android.httpclient.util.EntityUtils;

/**
 * Created by David.Obregon on 27/11/2017.
 */

public class ResultActivity extends AppCompatActivity {

    private TextView lblResultado;
    private String direccion;
    private String respStr;
    private class TaskGetRest extends AsyncTask<String,Integer,Boolean>
    {
        @Override
        protected Boolean doInBackground(String... strings)
        {
            boolean resul=true;
            //        HttpClient httpClient = new DefaultHttpClient();
            HttpClient httpClient = HttpClientBuilder.create().build();
            HttpGet del = new HttpGet(URL);
            del.setHeader("content-type","application/json");
            try
            {
                HttpResponse response = httpClient.execute(del);
                respStr = EntityUtils.toString(response.getEntity());
//                JSONObject jsnobject = new JSONObject(respStr);
//                JSONArray jsonArray = new JSONArray(respStr);
//                JSONObject respJSON = new JSONObject(respStr.replace("\n", ""));
//                direccion = respJSON.getString("direccion");

            }
            catch (Exception ex)
            {
                Log.e("ServicioRest","Error!",ex);
            }
            return resul;
        }

        protected void OnPostExecute(Boolean result)
        {
            if(result)
            {
                lblResultado.setText("Datos: " + respStr);
            }
        }
    }

    private static final String URL = "https://www.datos.gov.co/resource/72xi-wc2f.json";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.result_activity);

        //Get variables from previous activity
        String address = getIntent().getStringExtra("ADDRESS");
        String name = getIntent().getStringExtra("NAME");
        String number = getIntent().getStringExtra("NUMBER");
        String phone = getIntent().getStringExtra("PHONE");

        RequestParams rp = new RequestParams();
        if(address!=null)
            rp.add("direccion", address);
        if(name!=null)
            rp.add("nombre",name);
        if(number!=null)
            rp.add("num", number);
        if(phone!=null)
            rp.add("telefono", phone);

        //Call REstApi

        TaskGetRest tarea = new TaskGetRest();
        tarea.execute("abc");

//        HttpUtils.get(URL, rp, new JsonHttpResponseHandler() {
//
//            public void onSuccess(int statusCode, PreferenceActivity.Header[] headers, JSONObject response) {
//                // If the response is JSONObject instead of expected JSONArray
//                Log.d("asd", "---------------- this is response : " + response);
//                try {
//                    JSONObject serverResp = new JSONObject(response.toString());
//                } catch (JSONException e) {
//                    // TODO Auto-generated catch block
//                    e.printStackTrace();
//                }
//            }
//
//            public void onSuccess(int statusCode, PreferenceActivity.Header[] headers, JSONArray timeline) {
//                // Pull out the first event on the public timeline
//
//            }
//        });

    }
}

